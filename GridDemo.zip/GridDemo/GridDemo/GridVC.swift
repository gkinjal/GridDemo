//
//  GridVC.swift
//  GridDemo
//
//  Created by Kinjal Gadhia on 28/11/22.
//

import UIKit
import Alamofire

class GridVC: UIViewController {
    
    var imageList = [ImageStructure]()
    @IBOutlet weak var gridCV: UICollectionView!{
        didSet{
            gridCV.delegate = self
            gridCV.dataSource = self
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        callAPI()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    func callAPI() {
        
        guard let url = URL(string: "https://raw.githubusercontent.com/obvious/take-home-exercise-data/trunk/nasa-pictures.json")
        else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            guard let data = data else { return }
            
            do {
                self.imageList = try JSONDecoder().decode([ImageStructure].self, from: data)
                DispatchQueue.main.async {
                    self.gridCV.reloadData()
                }
                
                
            }
            catch {
                print(error)
            }
            
        }.resume()
        
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension GridVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: GridCC.identifier, for: indexPath) as? GridCC else {
            fatalError("Cell can't be dequeue")
        }
        cell.imgView.layer.cornerRadius = 10.0
        cell.imgView.clipsToBounds = true
        cell.imgView.downLoadImage(url: imageList[indexPath.row].url ?? "")
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let nextVC = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "DetailVC") as? DetailVC
        
        nextVC?.detail = imageList[indexPath.row]
        self.navigationController?.pushViewController(nextVC!, animated: true)
    }
    
    
    
    //MARK: UICollectionViewDelegateFlowLayout Methods
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.frame.size.width / 2-5, height:collectionView.frame.size.width / 2-5)
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right:0)
    }
    
    
}
