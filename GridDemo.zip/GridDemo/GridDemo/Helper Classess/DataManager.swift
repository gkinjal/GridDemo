//
//  DataManager.swift
//  GridDemo
//
//  Created by Kinjal Gadhia on 29/11/22.
//

import Foundation


struct ImageStructure: Decodable {
    let copyright: String?
    let date: String?
    let explanation: String?
    let hdurl: String?
    let media_type: String?
    let service_version: String?
    let title: String?
    let url: String?
}
