//
//  DetailVC.swift
//  GridDemo
//
//  Created by Kinjal Gadhia on 29/11/22.
//

import UIKit

class DetailVC: UIViewController {

    var detail : ImageStructure?
    @IBOutlet weak var lblExplan: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblCopyright: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        updateDetail()
    }
    func updateDetail(){
        lblExplan.text = detail?.explanation
        lblDate.text = detail?.date
        if detail?.copyright == nil {
            lblCopyright.isHidden = true
        }
        lblCopyright.text = detail?.copyright
        lblName.text = detail?.title
        imgView.downLoadImage(url: detail?.hdurl ?? "")
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
