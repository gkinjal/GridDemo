//
//  GridCC.swift
//  GridDemo
//
//  Created by Kinjal Gadhia on 28/11/22.
//

import UIKit

class GridCC: UICollectionViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
}
